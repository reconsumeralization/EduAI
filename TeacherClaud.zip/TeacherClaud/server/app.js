// app.js

const express = require('express');
const mongoose = require('mongoose');
const apiRouter = require('./routes/api');

const app = express();

// DB connection
mongoose.connect(process.env.DB_URL, {
  useNewUrlParser: true,
  useUnifiedTopology: true  
});

// Parse request body
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// API router
app.use('/api', apiRouter);

// Start server
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Server running on port ${port}`));