// Require ForumThread model

// Forum CRUD methods

module.exports = {
  getThreads, 
  createThread,
  getThreadById, 
  addComment,
  deleteThread
}