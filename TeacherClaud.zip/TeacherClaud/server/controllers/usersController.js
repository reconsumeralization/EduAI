
// controllers/usersController.js

const User = require('../models/User');
const { hashPassword, comparePasswords } = require('../utils/auth');

module.exports = {

  register: async (req, res) => {
    const { name, email, password } = req.body;

    try {
      // Hash password
      const hashedPassword = await hashPassword(password);
      
      // Create user
      const user = await User.create({
        name,
        email,
        password: hashedPassword
      });

      res.status(201).json(user);

    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Error registering user' });
    }
  },

  login: async (req, res) => {
    // Find user + validate password
    
    // Send JWT token
  },

  // Other controller methods
  
}