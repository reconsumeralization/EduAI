// Require User model

// Auth controller methods:
// Register, login, getUser, etc.

module.exports = {
  registerUser,
  loginUser,
  getUserProfile
}