// CRUD methods for lessons

const Lesson = require('../models/Lesson');

module.exports = {
  getLessons,
  getLesson,
  createLesson,
  updateLesson,
  deleteLesson
}