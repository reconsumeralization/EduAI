const mongoose = require('mongoose');

const threadSchema = new mongoose.Schema({
  title: String,
  text: String,
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User'},
  comments: [{
    text: String,
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
  }]
});

module.exports = mongoose.model('ForumThread', threadSchema);