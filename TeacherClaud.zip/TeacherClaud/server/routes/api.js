// routes/api.js

const express = require('express');
const router = express.Router();

const usersCtrl = require('../controllers/usersController');
const coursesCtrl = require('../controllers/coursesController');

router.post('/users', usersCtrl.register);
router.post('/users/login', usersCtrl.login);

router.get('/courses', coursesCtrl.index);
router.get('/courses/:id', coursesCtrl.show);

// Other routes...

module.exports = router;