// Forum routes 

const express = require('express');
const router = express.Router();

const forumCtrl = require('../controllers/forumController');

router.get('/', forumCtrl.getThreads);

// etc.

module.exports = router;