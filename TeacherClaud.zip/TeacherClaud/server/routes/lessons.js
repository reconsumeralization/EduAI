const express = require('express');
const router = express.Router();
const lessonsCtrl = require('../controllers/lessonsController');

// Lessons routes go here

module.exports = router;