# Database connection and model utilities

from pymongo import MongoClient

client = MongoClient(MONGO_URI)
db = client['education_db']

def get_courses_collection():
  return db['courses']

def get_users_collection():
  return db['users']