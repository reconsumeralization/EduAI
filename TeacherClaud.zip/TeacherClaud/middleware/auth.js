// Auth middleware for protecting routes
const jwt = require('jsonwebtoken');

const auth = (req, res, next) => {
  // Get token from header
  // Verify token
  // Attach user to req object
  // Call next()
}

module.exports = auth;