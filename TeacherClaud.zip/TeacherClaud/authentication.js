const jwt = require('jsonwebtoken');

// Generate JWT on login

const token = jwt.sign({ userId }, 'secretkey');

// Verify JWT on protected routes

const auth = (req, res, next) => {
  const token = req.header('Authorization');
  if(!token) return res.status(401).send('No token');
  
  try {
    const verified = jwt.verify(token, 'secretkey');
    req.user = verified;  
    next();
  } catch(err) {
    res.status(400).send('Invalid token');
  }
}
export const AuthProvider = ({ children }) => {
  // Auth state and methods like login, logout
} 

export const RequireAuth = ({ children }) => {
  // Get auth state and check user
  // Redirect to /login if no user

  return children;
}

export const useAuth = () => {
  // Custom hook to use auth context
}