// LessonPage.js

import { useParams } from 'react-router-dom';

export default function LessonPage() {
  
  const { moduleId, lessonId } = useParams();

  return (
    <div className="lesson">
      <VideoPlayer src={sampleVid} />

      <h2>Quiz</h2>

      <form>
        <Question
          text="What is the difference between margin and padding?"
          answers={['Spacing between elements', 'Spacing within an element']}
          userAnswer="Spacing within an element" 
          correct
        />

        <Question 
          text="What are the options for CSS position property?"
          answers={['Static', 'Relative', 'Absolute', 'Fixed', 'Sticky']}
        />

        <button type="submit">Submit Quiz</button>
      </form>
    </div>
  );
}