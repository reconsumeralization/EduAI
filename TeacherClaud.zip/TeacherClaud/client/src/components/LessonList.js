import LessonCard from './LessonCard';

const LessonList = ({ lessons }) => {

  return (
    <div className="lesson-list">
      {lessons.map(lesson => (
        <LessonCard key={lesson._id} lesson={lesson} /> 
      ))}
    </div>
  );
}