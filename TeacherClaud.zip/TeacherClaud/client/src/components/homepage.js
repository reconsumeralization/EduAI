/ Homepage.js

import { useState, useEffect } from 'react';
import CourseCard from '../components/CourseCard';

export default function Homepage() {
  
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    getFeaturedCourses();
  }, []);

  async function getFeaturedCourses() {
    const response = await fetch('/api/courses/featured');
    const data = await response.json();
    setCourses(data);
  }

  return (
    <main>
      <Banner />

      <h2>Featured Courses</h2>
      
      <div className="course-list">
        {courses.map(course => (
          <CourseCard key={course._id} course={course} />
        ))}
      </div>
    </main>
  );
}