// CoursePage.js

import { useParams } from 'react-router-dom';
import { useState, useEffect } from 'react';

export default function CoursePage() {

  const { id } = useParams();

  const [course, setCourse] = useState({});

  useEffect(() => {
    getCourseDetails(id);
  }, [id]);

  async function getCourseDetails(id) {
    const response = await fetch(`/api/courses/${id}`);
    const data = await response.json();
    setCourse(data);
  }

  return (
    <div className="course-page">
      <h1>{course.title}</h1>
      <p>By {course.instructor}</p>

      <video src={course.promoVideo} controls />

      <div className="details">
        <p>{course.description}</p>
        <p>Modules: {course.numModules}</p>
      </div>

      <button>Enroll Now</button>
    </div>
  );
}