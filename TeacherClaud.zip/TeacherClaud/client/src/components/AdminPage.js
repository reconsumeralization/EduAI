// AdminPage.js

import { useContext } from 'react';
import { AuthContext } from '../context/auth';
import CourseTable from '../components/CourseTable';
import UserTable from '../components/UserTable';

export default function AdminPage() {

  const { admin } = useContext(AuthContext);

  if (!admin) {
    return <Redirect to="/" />;
  }

  return (
    <div className="admin-page">
      <h1>Admin Portal</h1>
      
      <CourseTable />
      
      <UserTable />

    </div>
  );

}