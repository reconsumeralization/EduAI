// Footer.js

export default function Footer() {
  return (
    <footer>
      <div className="copyright">
        &copy; EduPlatform 2023
      </div>

      <div className="links">
        <a href="/terms">Terms</a>
        <a href="/privacy">Privacy</a>
      </div>
    </footer>
  );
}