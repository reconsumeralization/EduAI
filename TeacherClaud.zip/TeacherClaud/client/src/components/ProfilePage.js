// ProfilePage.js

import { useContext } from 'react';
import { AuthContext } from '../context/auth';

export default function ProfilePage() {
  
  const { user } = useContext(AuthContext);

  return (
    <div className="profile">
      <h2>Profile</h2>

      <p>Name: {user.name}</p>
      <p>Email: {user.email}</p>
      
      <h3>Course Progress</h3>
      
      {user.courses.map(course => (
        <div key={course._id}>
          <p>{course.title}</p>
          <p>Completed {course.completedLessons} of {course.totalLessons} lessons</p>
        </div>
      ))}

    </div>
  );

}