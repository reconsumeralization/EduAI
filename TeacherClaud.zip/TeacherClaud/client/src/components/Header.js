// Header.js

import { Link } from 'react-router-dom';

export default function Header() {

  return (
    <header>
      <div className="logo">
        <Link to="/">EduPlatform</Link>  
      </div>

      <nav>
        <Link to="/courses">Courses</Link>
        <Link to="/forum">Forum</Link>
        <Link to="/profile">Profile</Link>
      </nav>

    </header>
  );
}