// ForumPage.js

import { useState, useEffect } from 'react';
import ForumTopic from '../components/ForumTopic';

export default function ForumPage() {

  const [topics, setTopics] = useState([]);

  useEffect(() => {
    getTopics();
  }, []);

  async function getTopics() {
    // fetch topics from API
  }

  return (
    <div className="forum-page">
      <h1>Forum</h1>

      <div className="topics">
        {topics.map(topic => (
          <ForumTopic 
            key={topic.id}
            title={topic.title} 
            replies={topic.replyCount}
          />
        ))}
      </div>
    </div>
  );

}