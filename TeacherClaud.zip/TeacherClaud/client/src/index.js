import { AuthProvider } from './authentication';

ReactDOM.render(
  <AuthProvider>
    <App />
  </AuthProvider>, 
  document.getElementById('root')
);