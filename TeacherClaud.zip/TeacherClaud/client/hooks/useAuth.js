// Custom hook to handle auth state

import { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../context/AuthContext';

export default function useAuth() {
  const [loading, setLoading] = useState(true);
  const auth = useContext(AuthContext);
  
  useEffect(() => {
    // Check auth status
    setLoading(false);
  }, []);

  return { loading, auth }
}