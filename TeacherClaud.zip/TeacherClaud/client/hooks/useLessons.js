// Custom hook to fetch lessons

import { useState, useEffect } from 'react';
import axios from 'axios';

export default function useLessons(courseId) {
  const [lessons, setLessons] = useState([]);

  useEffect(() => {
    const fetchLessons = async () => {
      const res = await axios.get('/api/lessons/'+courseId);
      setLessons(res.data);
    }
    fetchLessons();
  }, [courseId]);

  return lessons;
}