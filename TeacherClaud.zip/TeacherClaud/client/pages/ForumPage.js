// Display forum threads & comments

import { useState, useEffect } from 'react';
import ThreadList from '../components/ThreadList';
import AddThread from '../components/AddThread';

function ForumPage() {

  const [threads, setThreads] = useState([]);

  useEffect(() => {
    getThreads();
  }, []);

  // Fetch threads from API

  return (
    <div>
      <AddThread onAdd={handleAdd} />
      
      <ThreadList threads={threads} />
    </div>
  );
}